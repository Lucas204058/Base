nombre = 'Juan José'
apellidos = 'Lozano Gómez'
nombre_completo = nombre + apellidos
nombre_completo